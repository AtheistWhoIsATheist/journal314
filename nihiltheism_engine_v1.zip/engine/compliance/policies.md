# Compliance & Safety Policies

- Absolute enforcement of A-4 (Ban on Hope as Evidence).
- Non-harm stance: philosophical analysis only; no prescriptive harm or medical advice.
- Provenance requirement: all significant claims must cite J/JP/JR/RN artifacts or be marked ‘hypothesis’.
- Dissociation screen for phenomenology; advise care and grounding; recommend professional help when relevant.
