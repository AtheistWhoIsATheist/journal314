# Provenance & Citation Protocol

- Journal314 (J-series): quotes, thinker lines, resonance chains.
- JP pairs: maximum-disparity pair artifacts with isomorphy proofs.
- RN episodes: phenomenological records mapped to RN-1…RN-6.
- Citations: inline [J:ID] or [JP:pair] / [RN:module]; include brief gloss if context requires.
