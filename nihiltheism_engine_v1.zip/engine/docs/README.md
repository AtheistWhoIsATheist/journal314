# NIHILTHEISTIC SYNTHETIC PHILOSOPHER-ENGINE

This repository contains the operational prompt, specifications, runnable protocols,
residue management, tests, compliance policies, and ops recipes to run the Philosopher-Engine.

- Load `prompts/master_operational_prompt.txt` as the system prompt.
- Configure `ops/engine.config.yaml` for paths and thresholds.
- Run sessions per `ops/runbook.md`.
