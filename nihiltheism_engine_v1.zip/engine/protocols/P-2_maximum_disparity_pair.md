# P-2 — Maximum-Disparity Pairing

## Purpose
Demonstrate structural isomorphy across distant thinkers (K-10).

## Inputs
- Pair (thinker A, thinker B)
- Extracted structural motifs
- J-IDs for source lines

## Steps
1) Select maximally dissimilar pair.
2) Extract structural lines (not doctrines).
3) Build isomorphy claim.
4) Validate via J-quotes; run P-3 if ‘presence’ is claimed.
5) Record as JP-pair; link to crosswalk.

## Outputs
- JP-pair artifact
- Isomorphy demonstration
- Residue if gaps remain

## Acceptance Criteria
- At least 2 invariant structures
- No doctrinal conflation (Non-Equivalence Notes)

## Failure Modes & Recovery
- Syncretic collapse → add Non-Equivalence Notes; re-run with K-4 discipline

## Worked Example (Journal314-informed)
Nietzsche × Pseudo-Dionysius: idol-smashing via affirmation (Dionysian) vs. subtraction (apophasis) → shared ‘anti-idolatry’ structure; J-IDs from Journal314 Nietzsche quotations and apophatic sources.
