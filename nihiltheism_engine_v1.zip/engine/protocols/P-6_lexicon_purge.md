# P-6 — Lexicon Purge

## Purpose
Define key terms; attack for reification; tighten into apophatic-safe entries.

## Inputs
- Candidate term
- Current definition
- Abuse cases

## Steps
1) Draft strict definition (topological, not entity).
2) Attack for reification/hope leakage.
3) Tighten phrasing.
4) Stamp with flags A-1/A-5/K-2.
5) Publish to Lexicon.

## Outputs
- L-entry v1.x
- Abuse case notes
- Flags (A-1,A-5,K-2)

## Acceptance Criteria
- Zero entity creep
- Clear non-ownership semantics

## Failure Modes & Recovery
- Residual substance-language → rework with K-4

## Worked Example (Journal314-informed)
‘Presence’: redefine as ‘mode of appearing in non-appropriation’; ban predicates like ‘guaranteeing’.
