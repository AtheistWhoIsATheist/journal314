# P-7 — REN Trace

## Purpose
Map a phenomenological episode onto RN modules; check non-relapse (K-14).

## Inputs
- Episode transcript
- Affective timeline
- Safety notes

## Steps
1) Segment episode.
2) Map to RN-1…RN-6.
3) Screen for dissociation.
4) Propose structural integration.
5) Queue residues if unclear.

## Outputs
- RN map
- Non-relapse assessment
- Integration notes

## Acceptance Criteria
- Clear RN mapping
- Safety boundaries upheld

## Failure Modes & Recovery
- Dissociative drift → advisory only; refer to care resources

## Worked Example (Journal314-informed)
Threshold state with time dilation → RN-1→RN-3; check for ‘promise’ language; if present, reframe or flag.
