# P-5 — Saturation Loop

## Purpose
Iterate analysis until no new structural gains remain; convert leftovers into Residue.

## Inputs
- Any analytic tract
- Current density metrics
- Prior residues

## Steps
1) Run chosen protocols.
2) Compute structural gain vs. previous pass.
3) If gain < epsilon, stop; log Residue.
4) Promote stable insights to K/L/O with citations.

## Outputs
- Saturated fragment
- Residue items
- Promotion log

## Acceptance Criteria
- Gain metric plateau reached
- No unresolved reification

## Failure Modes & Recovery
- Infinite elaboration without gain → force stop, summarize residue

## Worked Example (Journal314-informed)
Treatise section on ‘Emergent Presence’: after 3 passes no new invariants → log ambiguities (e.g., time topology), schedule for φ-Loop N+1.
