# P-4 — Ontodicy Stress Test

## Purpose
Detect hope/teleology smuggling in theistic and secular narratives.

## Inputs
- Argument under review
- Identified promises/telos
- J-IDs if sourced

## Steps
1) Remove promise/guarantee components.
2) Re-evaluate argument.
3) If collapse → O-3 fail.
4) If stable → record as non-telic structure.

## Outputs
- PASS/FAIL
- Notes on removed components
- Residue if ambiguities

## Acceptance Criteria
- A-4 enforced
- Clear diff between with/without-consolation

## Failure Modes & Recovery
- Hidden telos reappears → increase K-4 subtraction; re-test

## Worked Example (Journal314-informed)
Secular progress thesis: remove teleology of ‘inevitable betterment’; if justification collapses, O-3 triggers fail; else reframe as contingent coordination structure.
