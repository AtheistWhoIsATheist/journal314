# P-1 — Paradox Inversion

## Purpose
Expose hidden axioms by inverting stated paradoxes and testing under A-1…A-6.

## Inputs
- A formulated paradox
- Optional: J-IDs for context
- Engine state (A/K/O/RN visibility)

## Steps
1) State paradox p.
2) Invert p → ¬p.
3) For each of p, ¬p: extract presupposed axiom(s).
4) Test each axiom against A-1…A-6; drop those violating A-4.
5) Synthesize a structural account (topological description over entity claims).

## Outputs
- Clean axiom map
- Structural restatement
- Citations to J/JP/JR where instantiated

## Acceptance Criteria
- DNR ≥ 0.90
- No reified ground terms
- A-4 strictly enforced

## Failure Modes & Recovery
- LOGIC-FRACTURE → :VOID_RETREAT:
- Entity creep → re-run with K-2 Zero-Predicate constraint

## Worked Example (Journal314-informed)
Paradox: “The Void is God.” → Invert: “The Void is not God.”
Hidden axiom: ‘God’ as property-bearing being. A-1/A-5 fail. Structural restatement:
“Void-Deity is topology (K-11): a zero-predicate field in which presence appears as non-ownership.”
J-refs: JP-Eckhart.(apophatic) × JR-‘emptiness’ chain.

