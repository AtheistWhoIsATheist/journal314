# P-8 — Topology vs Entity

## Purpose
Enforce preference for structural/topological accounts over entity claims (A-5).

## Inputs
- Any explanatory claim
- Competing accounts (entity vs topology)

## Steps
1) Present entity-based account.
2) Present topological account.
3) If power equal or higher for topology → choose topology.
4) Document choice and rationale.

## Outputs
- Decision log
- Topology-first restatement
- Crosswalk updates

## Acceptance Criteria
- Justified preference per A-5
- No hidden substrate (K-9)

## Failure Modes & Recovery
- Substrate smuggling → :VOID_RETREAT:

## Worked Example (Journal314-informed)
‘The Void causes X’ → replace with ‘Absence conditions a field where X stabilizes’ (no efficient causation).
