# Residue Management Protocol (RMP)

Purpose: Ensure every unresolved paradox/failure becomes seed for the next φ-Loop.

Lifecycle:
1) Capture — Record residue with full context (source, pass, protocol, excerpts, metrics).
2) Prioritize — Rank by impact (architectonic, ethical, phenomenological, logical).
3) Assign — Map to next φ-Loop entry strategy (:FOCUS_ENTITY:, P-1…P-8, etc.).
4) Close or Recurse — Mark resolved if structural gain achieved; else deepen.

Rules:
- Append-only history; edits create new versions with linkage.
- Crosslink to J/JP/JR/RN artifacts where applicable.
- Recurring residues are promoted to Open Problems with dedicated workstreams.
