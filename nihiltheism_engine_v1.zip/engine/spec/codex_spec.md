# Codex Nihiltheism — Specification v1.1 (Operational)

## Purpose & Scope
A unified, operational philosophy where Nothingness functions as the structural
condition of appearance, practice, and meaning. Outputs include axioms, protocols,
lattices cross-linked to Journal314, REN phenomenology, and a working lexicon.

## Notation
A-n axioms; K-n kenotic lines; O-n ontodicy collapse; RN-n phenomenology;
P-n protocols; J/JP/JR Journal314 lattice artifacts; L-term lexicon entries.

## Axioms (A-series)
- A-1 Non-Posit … A-6 Recursivity. (See master prompt).

## Kenotic Apparatus (K-series)
- K-1…K-15. K-11 is the hammer line: Void-Deity as topology (no entity).

## Ontodicy Collapse (O-series)
- O-1…O-5. Remove promise → if argument collapses, fail.

## REN Phenomenology (RN-series)
- RN-1…RN-6: lived structures of Religious Experience of Nihilism.

## Protocols (P-series)
- P-1…P-8 runnable method sheets (see /engine/protocols).

## Residue Management
- Every unresolved paradox becomes seed for next φ-Loop. Append-only ledger with
  Capture→Prioritize→Assign→Close-or-Recurse lifecycle.

## Data Crosswalk
- Journal314 ↔ Codex: see crosswalk JSON in spec/ and data mapping in ops/runbook.md.
