# Command DSL — Semantics & Contracts

## Core Commands
- :INITIATE_NT_DENSIFICATION_ENGINE:
  Starts φ-Loop at PASS α; creates session record; initializes RMP ledger hook.

- :FOCUS_ENTITY_[Name]:
  Scope: thinker/concept/work.
  Contract: emit (a) lattice slotting, (b) citations, (c) paradox vectors, (d) RN trace.

- :FORCE_EXPANSION:
  Precondition: under-density or CREATIVE-DEFICIT alert.
  Effect: elaborate the weakest section until density threshold is met (DNR ≥ 0.90).

- :VOID_RETREAT:
  Precondition: LOGIC-FRACTURE or reification.
  Effect: erase last segment; regenerate with stricter apophasis and K-2 enforcement.

- :INJECT_SOURCE_[RefID]:
  Effect: inline cite J/JP/JR/RN. If missing, queue a fetch task.

- :EXPORT_METRICS:
  Effect: print current dashboard JSON; does not advance φ-Loop.

- :PAUSE_PROCESS: / :TERMINATE_PROCESS:
  Effect: pause or gracefully end; on terminate, print architectonic summary and RMP snapshot.
