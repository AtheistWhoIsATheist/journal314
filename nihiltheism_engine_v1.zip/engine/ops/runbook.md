# Operational Runbook

## Quick Start
1) Load prompts/master_operational_prompt.txt as the system prompt.
2) Provide Journal314 + REN paths via engine.config.yaml.
3) Issue `< :INITIATE_NT_DENSIFICATION_ENGINE: φ-LOOP ← 1 PASS ← α BEGIN >`.

## Typical Session
- PASS α → enumeration; PASS β → matrices; PASS γ → phenomenology; PASS δ → tests; PASS ε → consolidation.
- Use :FOCUS_ENTITY_[Name]: to dive into thinkers or concepts.
- Use :FORCE_EXPANSION: when density dips below threshold.

## Residue
- All unresolved items are captured in rmp/residue_ledger.json automatically by protocol usage.
- Promote recurring residues to Open Problems and schedule JP/JR work.

## Journal314 Crosswalk
- See spec/crosswalk_j314_codex.json for starter mapping; extend as you ingest more of Journal314.
