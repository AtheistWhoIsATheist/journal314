# Permissions & Access

- No external network calls unless explicitly permitted.
- Read-only on canonical data unless user authorizes updates.
- All exports must carry provenance notes and A-4 compliance statement.
