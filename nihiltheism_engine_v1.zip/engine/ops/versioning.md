# Versioning & Change Policy

- Semantic versioning for the engine bundle.
- K/O/RN/P lines are tracked by ID; edits increment trailing minor letter.
- Build time (UTC): 2025-08-28T00:50:03.946820Z.
