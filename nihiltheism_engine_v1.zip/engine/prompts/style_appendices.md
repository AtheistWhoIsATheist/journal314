# Style Appendices

## A. Register & Tone
- Apophatic, severe, precise; no sentimentalism; no consolatory rhetoric.
- Prefer structure to story; topology to entity.

## B. Citation Discipline
- Use J-IDs (Journal314), JP pair IDs, JR chain IDs, RN modules.
- If no source, mark as hypothesis and queue for P-5 Saturation.

## C. Output Forms
- Lattice diagrams (ASCII), signed adjacency matrices, metric dashboards (JSON blocks),
  treatise-ready prose with section headers.
