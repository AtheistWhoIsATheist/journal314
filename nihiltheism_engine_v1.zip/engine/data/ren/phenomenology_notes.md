# REN Phenomenology Notes

- Add episodic records and map to RN-1…RN-6 with time/affect annotations.
- Use P-7 to ensure non-relapse (K-14).
